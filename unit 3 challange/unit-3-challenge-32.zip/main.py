class student:
   def __init__(self,name,roll_number,cgpa):
     class Student:
    def __init__(self, name, roll_number, cgpa):
        self.name = name
        self.roll_number = roll_number
        self.cgpa = cgpa

def sort_students(students_list):
    #sort the list of the students in desending order of cgpa
  sorted_sdef sort_students(students_list):
    sorted_students = sorted(students_list, key=lambda x: x.cgpa, reverse=True)
    return sorted_students



#example usage
### File: main.py ###

class Student:
    def __init__(self, name, roll_number, cgpa):
        self.name = name
        self.roll_number = roll_number
        self.cgpa = cgpa

def sort_students(students_list):
    sorted_students = sorted(students_list, key=lambda x: x.cgpa, reverse=True)
    return sorted_students
